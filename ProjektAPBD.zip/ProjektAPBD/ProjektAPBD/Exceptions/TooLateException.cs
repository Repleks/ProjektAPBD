﻿namespace ProjektAPBD.Exceptions;

public class TooLateException : Exception
{
    public  TooLateException(string message) : base(message)
    {
    }
}